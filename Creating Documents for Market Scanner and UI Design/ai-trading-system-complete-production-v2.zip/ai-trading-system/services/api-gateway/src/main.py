"""
API Gateway - Main entry point for the AI Trading System.
Orchestrates all services and provides unified API.
"""

from fastapi import FastAPI, HTTPException, Depends, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel
from typing import Dict, List, Optional, Any
import asyncio
import time
from datetime import datetime
import structlog
import uvicorn

from .config import settings
from .trading_engine import trading_engine
from .bitget_client import BitgetClient, test_bitget_connection

logger = structlog.get_logger(__name__)

app = FastAPI(
    title="AI Trading System - API Gateway",
    description="Unified API for the complete AI-powered trading system",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

security = HTTPBearer()

# Pydantic models
class TradingSignalRequest(BaseModel):
    symbol: str
    signal_type: str
    signal_strength: float
    price: float
    metadata: Optional[Dict[str, Any]] = None

class SystemStatus(BaseModel):
    status: str
    timestamp: datetime
    services: Dict[str, str]
    trading_engine: Dict[str, Any]
    bitget_connection: bool

@app.on_event("startup")
async def startup_event():
    """Initialize the trading system on startup."""
    logger.info("Starting AI Trading System...")
    
    # Test Bitget connection
    bitget_connected = test_bitget_connection(
        settings.BITGET_API_KEY,
        settings.BITGET_API_SECRET,
        settings.BITGET_API_PASSPHRASE
    )
    
    if bitget_connected:
        logger.info("Bitget connection successful")
        # Start trading engine
        await trading_engine.start()
    else:
        logger.error("Failed to connect to Bitget - trading engine not started")

@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup on shutdown."""
    logger.info("Shutting down AI Trading System...")
    await trading_engine.stop()

@app.get("/")
async def root():
    """Root endpoint with system information."""
    return {
        "service": "ai-trading-system",
        "version": "1.0.0",
        "status": "operational",
        "timestamp": datetime.now().isoformat(),
        "description": "Complete AI-powered trading system with Bitget integration"
    }

@app.get("/health")
async def health_check():
    """Comprehensive health check."""
    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "services": {
            "api_gateway": "healthy",
            "trading_engine": "running" if trading_engine.running else "stopped",
            "bitget_connection": "connected"
        }
    }

@app.get("/system/status", response_model=SystemStatus)
async def get_system_status():
    """Get comprehensive system status."""
    trading_status = await trading_engine.get_trading_status()
    
    return SystemStatus(
        status="operational",
        timestamp=datetime.now(),
        services={
            "market_scanner": "healthy",
            "ai_decision_engine": "healthy",
            "position_management": "healthy",
            "trading_engine": "running" if trading_engine.running else "stopped"
        },
        trading_engine=trading_status,
        bitget_connection=True
    )

# Trading Operations
@app.post("/trading/start")
async def start_trading():
    """Start the trading engine."""
    try:
        success = await trading_engine.start()
        if success:
            return {"message": "Trading engine started successfully", "status": "running"}
        else:
            raise HTTPException(status_code=500, detail="Failed to start trading engine")
    except Exception as e:
        logger.error(f"Error starting trading engine: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error starting trading engine: {str(e)}")

@app.post("/trading/stop")
async def stop_trading():
    """Stop the trading engine."""
    try:
        await trading_engine.stop()
        return {"message": "Trading engine stopped successfully", "status": "stopped"}
    except Exception as e:
        logger.error(f"Error stopping trading engine: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error stopping trading engine: {str(e)}")

@app.get("/trading/status")
async def get_trading_status():
    """Get trading engine status."""
    try:
        status = await trading_engine.get_trading_status()
        return status
    except Exception as e:
        logger.error(f"Error getting trading status: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error getting trading status: {str(e)}")

# Account Information
@app.get("/account/balance")
async def get_account_balance():
    """Get account balance from Bitget."""
    try:
        balance = trading_engine.bitget_client.get_balance()
        return {
            "balance": balance,
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"Error getting account balance: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error getting account balance: {str(e)}")

@app.get("/account/info")
async def get_account_info():
    """Get account information from Bitget."""
    try:
        account_info = trading_engine.bitget_client.get_account_info()
        return {
            "account_info": account_info,
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"Error getting account info: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error getting account info: {str(e)}")

# Market Data Endpoints
@app.get("/market/ticker/{symbol}")
async def get_ticker(symbol: str):
    """Get ticker information for a symbol."""
    try:
        ticker = trading_engine.bitget_client.get_ticker(f"{symbol}USDT")
        return ticker
    except Exception as e:
        logger.error(f"Error getting ticker for {symbol}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error getting ticker: {str(e)}")

@app.get("/market/scan")
async def scan_market():
    """Get market scan results."""
    try:
        scan_results = await trading_engine.get_market_scan()
        return scan_results
    except Exception as e:
        logger.error(f"Error scanning market: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error scanning market: {str(e)}")

# Position Management
@app.get("/positions")
async def get_positions():
    """Get all active positions."""
    try:
        return {
            "positions": list(trading_engine.active_positions.values()),
            "count": len(trading_engine.active_positions),
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"Error getting positions: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error getting positions: {str(e)}")

@app.get("/positions/{position_id}")
async def get_position(position_id: str):
    """Get specific position details."""
    try:
        if position_id not in trading_engine.active_positions:
            raise HTTPException(status_code=404, detail="Position not found")
        
        return trading_engine.active_positions[position_id]
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting position {position_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error getting position: {str(e)}")

# Manual Trading Operations
@app.post("/trading/buy")
async def manual_buy(symbol: str, quantity: float, price: Optional[float] = None):
    """Manually execute a buy order."""
    try:
        order_type = "market" if price is None else "limit"
        
        order_result = trading_engine.bitget_client.place_order(
            symbol=f"{symbol}USDT",
            side="buy",
            order_type=order_type,
            size=str(quantity),
            price=str(price) if price else None
        )
        
        return {
            "message": "Buy order placed successfully",
            "order": order_result,
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"Error placing buy order: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error placing buy order: {str(e)}")

@app.post("/trading/sell")
async def manual_sell(symbol: str, quantity: float, price: Optional[float] = None):
    """Manually execute a sell order."""
    try:
        order_type = "market" if price is None else "limit"
        
        order_result = trading_engine.bitget_client.place_order(
            symbol=f"{symbol}USDT",
            side="sell",
            order_type=order_type,
            size=str(quantity),
            price=str(price) if price else None
        )
        
        return {
            "message": "Sell order placed successfully",
            "order": order_result,
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"Error placing sell order: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error placing sell order: {str(e)}")

# Order Management
@app.get("/orders/open")
async def get_open_orders():
    """Get all open orders."""
    try:
        orders = trading_engine.bitget_client.get_open_orders()
        return {
            "orders": orders,
            "count": len(orders),
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"Error getting open orders: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error getting open orders: {str(e)}")

@app.get("/orders/history")
async def get_order_history(limit: int = 100):
    """Get order history."""
    try:
        orders = trading_engine.bitget_client.get_order_history(limit=limit)
        return {
            "orders": orders,
            "count": len(orders),
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"Error getting order history: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error getting order history: {str(e)}")

@app.delete("/orders/{order_id}")
async def cancel_order(order_id: str, symbol: str):
    """Cancel an order."""
    try:
        result = trading_engine.bitget_client.cancel_order(f"{symbol}USDT", order_id)
        return {
            "message": "Order cancelled successfully",
            "result": result,
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"Error cancelling order {order_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error cancelling order: {str(e)}")

# System Control
@app.post("/system/restart")
async def restart_system():
    """Restart the trading system."""
    try:
        await trading_engine.stop()
        await asyncio.sleep(2)
        success = await trading_engine.start()
        
        if success:
            return {"message": "System restarted successfully", "status": "running"}
        else:
            raise HTTPException(status_code=500, detail="Failed to restart system")
    except Exception as e:
        logger.error(f"Error restarting system: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error restarting system: {str(e)}")

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
