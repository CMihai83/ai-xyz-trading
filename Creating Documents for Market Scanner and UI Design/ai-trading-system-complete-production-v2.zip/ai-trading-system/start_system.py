#!/usr/bin/env python3
"""
AI Trading System Startup Script
Starts all services and the trading engine with Bitget integration.
"""

import asyncio
import subprocess
import time
import sys
import os
import signal
from pathlib import Path

class TradingSystemManager:
    def __init__(self):
        self.processes = []
        self.services = [
            ('api-gateway', 8000),
            ('market-scanner', 8001),
            ('ai-decision-engine', 8002),
            ('position-management', 8003),
            ('backtesting-engine', 8004),
            ('ml-framework', 8005),
            ('monitoring-service', 8006),
            ('notification-service', 8007),
            ('data-pipeline', 8008),
            ('risk-engine', 8009)
        ]
    
    def start_service(self, service_name, port):
        """Start a single service."""
        service_path = Path(f"services/{service_name}/src")
        
        if not service_path.exists():
            print(f"❌ Service path not found: {service_path}")
            return None
        
        print(f"🚀 Starting {service_name} on port {port}...")
        
        try:
            process = subprocess.Popen([
                sys.executable, "-m", "uvicorn", "main:app",
                "--host", "0.0.0.0",
                "--port", str(port),
                "--reload"
            ], cwd=service_path)
            
            self.processes.append((service_name, process))
            return process
            
        except Exception as e:
            print(f"❌ Failed to start {service_name}: {str(e)}")
            return None
    
    def start_all_services(self):
        """Start all services."""
        print("🎯 Starting AI Trading System...")
        print("=" * 50)
        
        for service_name, port in self.services:
            process = self.start_service(service_name, port)
            if process:
                time.sleep(2)  # Give each service time to start
        
        print("\n✅ All services started!")
        print("\n📊 Service URLs:")
        for service_name, port in self.services:
            print(f"  • {service_name}: http://localhost:{port}")
        
        print("\n🎯 Main API Gateway: http://localhost:8000")
        print("📈 Trading Dashboard: http://localhost:3000 (if frontend is running)")
        print("\n💡 Use Ctrl+C to stop all services")
    
    def stop_all_services(self):
        """Stop all services."""
        print("\n🛑 Stopping all services...")
        
        for service_name, process in self.processes:
            try:
                process.terminate()
                process.wait(timeout=5)
                print(f"✅ Stopped {service_name}")
            except subprocess.TimeoutExpired:
                process.kill()
                print(f"🔥 Force killed {service_name}")
            except Exception as e:
                print(f"❌ Error stopping {service_name}: {str(e)}")
        
        print("✅ All services stopped!")
    
    def signal_handler(self, signum, frame):
        """Handle shutdown signals."""
        self.stop_all_services()
        sys.exit(0)
    
    def run(self):
        """Run the trading system."""
        # Set up signal handlers
        signal.signal(signal.SIGINT, self.signal_handler)
        signal.signal(signal.SIGTERM, self.signal_handler)
        
        try:
            self.start_all_services()
            
            # Keep the main process running
            while True:
                time.sleep(1)
                
                # Check if any process has died
                for service_name, process in self.processes:
                    if process.poll() is not None:
                        print(f"⚠️  Service {service_name} has stopped unexpectedly")
        
        except KeyboardInterrupt:
            self.stop_all_services()
        except Exception as e:
            print(f"❌ Unexpected error: {str(e)}")
            self.stop_all_services()

if __name__ == "__main__":
    print("🤖 AI Trading System with Bitget Integration")
    print("=" * 50)
    print("🔑 Bitget API Key: bg_f483546274ffb2bfa567328e98dba6c0")
    print("🔐 Ready for live trading!")
    print("=" * 50)
    
    manager = TradingSystemManager()
    manager.run()
